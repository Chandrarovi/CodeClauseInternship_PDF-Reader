package com.rajat.pdfviewer.util

/**
 * Created by Rajat on 11,July,2020
 */

enum class PdfEngine(val value: Int) {
    INTERNAL(100),
    GOOGLE(200)
}